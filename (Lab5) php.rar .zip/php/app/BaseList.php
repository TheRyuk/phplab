<?php
abstract class BaseList {
    protected $lastId;
    protected $dataArray;

    public function __construct() {
        $this->lastId = 0;
        $this->dataArray = [];
    }

    public function update($params) {
        foreach ($this->dataArray as $item) {
            if ($item->getId() == $params['id']) {
                $item->update($params);
                break;
            }
        }
    }

    public function display() {
        foreach ($this->dataArray as $item) {
            $item->displayInfo();
        }
    }

    public function delete($id){
        for($i=0;$i<count($this->dataArray);$i++){
            if($this->dataArray[$i]->getId()==$id){
                array_splice($this->dataArray,$i,1);
                break;
            }
            
        }
    }

    public abstract function add($params);

    public function exportAsJSON(){
        $result=array();
        foreach($this->dataArray as $item){
            array_push($result,$item->getAsAssocArray());
        }
        return json_encode($result,JSON_UNESCAPED_UNICODE);
    }

    public function exportAsTableData(){
        $result='';
        foreach($this->dataArray as $item){
            $result.=$item->getAsTableRow();
        }
        return $result;
    }

    public function getItemById($id){
        foreach($this->dataArray as $item){
            if($item->getId()==$id){
                return $item->getAsAssocArray();
            }
        }
    }
}
